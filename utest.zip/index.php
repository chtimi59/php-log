<?php
if(!@include("conf.php")) { echo "Setup missing"; die(); }
date_default_timezone_set('America/Montreal');
session_start();
require 'libs/PHPLog/PHPLogAutoload.php';
$log = new PHPLogMailer(true);

define('ACTION_NONE',              0);
define('ACTION_LOGIN',             1);
define('ACTION_LOGOUT',            2);
define('ACTION_BADLOGIN',          3);
define('ACTION_ADDUSER',           4);
define('ACTION_DELETEUSER',        5);
define('ACTION_UPDATECURRENTUSER', 6);
define('ACTION_UPDATEUSER',        7);
define('ACTION_ADDCANDIDATE',      8);
define('ACTION_VERIFCANDIDATE',    9);
define('ACTION_DELETECANDIDATE',   10);
define('ACTION_FORGETPW'       ,   11);
define('ACTION_SENDMAIL'       ,   12);

?>

<html>
<style>
html {
    font-family: Arial, Helvetica, sans-serif;
}    
.activity {
    border-width: 1px;
    border-style: dotted;
    border-color: black;
    margin: 10px;
    padding: 10px;
    background-color: beige;
    color:black;
}
.operation {
    border-width: 1px;
    border-style: dotted;
    border-color: black;
    margin: 10px;
    padding: 10px;
    background-color: #CCFFCC;
}
a:link, a:visited {
    background-color: #4CAF50;
    color: white;
    padding: 14px 25px;
    margin: 5px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
}
a:hover, a:active {
    background-color: red;
}
li {
  list-style-type: none;
}
</style>
<body>

<div class="activity"><?php $log->dbg_print('State before'); ?></div>

<div class="activity">
<?php

/* fake a new user */
$name = "Alfred";
$password = "Toto1234";
$email = $GLOBALS['CONFIG']['smtp_email'];
$lang = 'en';

if (!isset($_GET['action'])) $_GET['action'] = ACTION_NONE;
if ( isset($_GET['verif'] )) $_GET['action'] = ACTION_VERIFCANDIDATE;
switch($_GET['action'])
{
    case ACTION_NONE:
        echo 'No Action<hr>';
        break;
       
       
    case ACTION_ADDCANDIDATE:
        echo 'Add Candidate<hr>';
        if (!$log->addCandidate($email,$lang )) {
            echo $log->lastError;
            break;
        }
        echo ("mail sent to $email<br>\n");
        break;
        
    case ACTION_VERIFCANDIDATE:
        echo 'Verif Candidate<hr>';
        $data = $log->getCandidate($_GET['verif']);
        if (!$data) {
            echo $log->lastError;
            break;
        } else {
            echo($data['EMAIL']." OK!<br>\n");
        }
        if (!$log->deleteCandidate($_GET['verif'])) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;
        
    case ACTION_DELETECANDIDATE:
        echo 'Delete Candidate<hr>';
        $data = $log->deleteCandidate('EE3E9ECE-6E8B-4C94-946C-D13187BBCE0F');
        if (!$data) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;
        
        
    case ACTION_ADDUSER:
        echo 'Add User<hr>';
        $user = array(
            'EMAIL' => $email,
            'PASSWORD' => $password,
            'PRIVILEGE' => 0,
            'FIRST_NAME' => $name,
        );
        if (!$log->addUser($user, $lang)) {
            echo $log->lastError;
            break;
        }
        echo ("$email created<br>\n");
        break;
        
    case ACTION_DELETEUSER:
        echo 'Delete User<hr>';        
        if (!$log->deleteUser($lang, $email, $password)) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;    
        
    case ACTION_LOGIN:
        echo 'Login<hr>';
        if (!$log->logIn($email,$password)) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;
        
    case ACTION_LOGOUT: 
        echo 'Logout<hr>';
        if (!$log->logOut()) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;
        
    case ACTION_BADLOGIN:
        echo 'Bad Login<hr>';
        if (!$log->logIn($GLOBALS['CONFIG']['admin_email'],'asdasd')) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;

    case ACTION_SENDMAIL:
        echo 'Send Mail<hr>';
        if (!$log->sendEmail('sample', $lang)) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;
        
     case ACTION_UPDATECURRENTUSER:
        echo 'Update Current User<hr>';
        $user = array(
            'UUID' => 'sadsadsa', /* should no be used */
            'FIRST_NAME' => $name.' II',
        );
        if (!$log->updateUser($user, $lang)) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;
        
    case ACTION_UPDATEUSER:
        echo 'Update User<hr>';
        $user = array(
            'UUID' => 'sadsadsa', /* should no be used */
            'EMAIL' => $email, /* change email */
            'PRIVILEGE' => 4, /* increase privilege */
            'FIRST_NAME' => 'God of the universe',
        );
        if (!$log->updateUser($user, $lang, $GLOBALS['CONFIG']['admin_email'], '1234')) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;
        
        
    case ACTION_FORGETPW:
        echo 'Forget Password<hr>';
        if (!$log->forgetPassword($email, $lang)) {
            echo $log->lastError;
            break;
        }
        echo "success!<br>\n";
        break;        
}
?>
</div>

<div class="activity"><?php $log->dbg_print('State after'); ?></div>

<br>
<div class="operation">
<br>
<a href="index.php?action=<?php echo ACTION_NONE; ?>">ACTION_NONE</a><br>
<br>
Adding a user process (step by step) :
<ul>
<li>Step1: <a href="index.php?action=<?php echo ACTION_ADDCANDIDATE; ?>">ACTION_ADDCANDIDATE</a> send an email to <?php echo $email ?></li>
<li>Step2: <a href="index.php?verif=12asd345">ACTION_VERIFCANDIDATE</a> Should normally be called-back from the email link, this button should say 'invalid uuid'</li>
<li>Step3: <a href="index.php?action=<?php echo ACTION_ADDUSER; ?>">ACTION_ADDUSER</a> create <?php echo "$name/$email" ?> user</li>
<li>Step4: <a href="index.php?action=<?php echo ACTION_DELETECANDIDATE; ?>">ACTION_DELETECANDIDATE</a></li>
<li>&nbsp;</li>
<li>To redo the test: <a href="index.php?action=<?php echo ACTION_DELETEUSER; ?>">ACTION_DELETEUSER</a> delete <?php echo "$name/$email" ?> user</li>
</ul>
User LogIn/LogOut :
<ul>
<li><a href="index.php?action=<?php echo ACTION_LOGIN; ?>">ACTION_LOGIN</a><?php echo "$name/$email" ?> user</li>
<li><a href="index.php?action=<?php echo ACTION_BADLOGIN; ?>">ACTION_BADLOGIN</a> with a wrong password</li>
<li><a href="index.php?action=<?php echo ACTION_LOGOUT; ?>">ACTION_LOGOUT</a></li>
<li><a href="index.php?action=<?php echo ACTION_SENDMAIL; ?>">ACTION_SENDMAIL</a>send email to logged user</li>
</ul>
User changes:
<ul>
<li><a href="index.php?action=<?php echo ACTION_UPDATECURRENTUSER; ?>">ACTION_UPDATECURRENTUSER</a> change current user name</li>
<li><a href="index.php?action=<?php echo ACTION_UPDATEUSER; ?>">ACTION_UPDATEUSER</a> change admin email and name</li>
<li><a href="index.php?action=<?php echo ACTION_FORGETPW; ?>">ACTION_FORGETPW</a> say that <?php echo "$email" ?> forget his password</li>
</ul>

</div>
</body>
</html>